package PR2.tut5;

public class PointTest {
    public static void main(String[] args) {
        MovablePoint mp = new MovablePoint(4.3f, 3, 2, 7);
        System.out.print(mp.toString());
    }
}
