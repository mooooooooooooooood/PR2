package PR2.tut6;

public interface Shape2DCalculation {
    public double getArea();
    public double getPerimeter();
}