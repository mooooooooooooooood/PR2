package PR2.tut6;

public interface SpecialAbility {
    public void transform();
    public void teleport(Point2D position);
}
