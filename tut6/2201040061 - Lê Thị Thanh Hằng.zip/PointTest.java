package PR2.tut6;

public class PointTest {
    public static void main(String[] args) {
        Point point1 = new Point();
        System.out.println("Point 1: " + point1);

        Point point2 = new Point(3.5f, 4.2f);
        System.out.println("Point 2: " + point2);


    }
}
